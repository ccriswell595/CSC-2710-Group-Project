#ifndef SORTING_ALGORITHMS_H
#define SORTING_ALGORITHMS_H

//void selectionSort(int arr[], int length);
//void bubbleSort(int arr[], int length);
//void insertionSort(int arr[], int length);
//void mergeSort(int arr[], int left, int right);
void quicksort(int arr[], int low, int high);
struct heap {
    int *S;
    int heapsize;
};
void heapsort(int n, heap& H, int S[]);

#endif 
